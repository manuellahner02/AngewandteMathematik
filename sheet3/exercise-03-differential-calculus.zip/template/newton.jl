using Plots

function plot_results(func, x, start, root, label)
    pLine = plot(x, func, xlabel="x", ylabel="y", label="", legend=:bottomright, title=label)
    plot!(pLine, [0], seriestype="hline", label="")
    scatter!(pLine, [start], [func(start)], color=:blue, label="start")
    scatter!(pLine, [root], [func(root)], color=:red, label="root")
end;


# -----------------------[ Exercise 3 ]------------------------------

function newton_method(func, func_prime, start::Float64, iter::Integer)::Float64
    x = start

    # TODO: Implement the iterative scheme of Newton's method for finding a root of a function

    x
end;

# TODO: Implement the functions f, g, h and their derivatives

f = (x) -> x
f_prime = (x) -> 1

g = (x) -> x
g_prime = (x) -> 1

h = (x) -> x
h_prime = (x) -> 1

# -----------------------[ Exercise 3 ]------------------------------


f_root = newton_method(f, f_prime, 3.0, 10)
g1_root = newton_method(g, g_prime, 2.5, 10)
g2_root = newton_method(g, g_prime, 1.0, 10)
h_root = newton_method(h, h_prime, 1/2, 10)

plt = plot(
        plot_results(f, -5:0.1:5, 3.0, f_root, "f(x)"),
        plot_results(g, -5:0.1:5, 2.5, g1_root, "g(x)"),
        plot_results(g, -5:0.1:5, 1.0, g2_root, "g(x)"),
        plot_results(h, -5:0.1:5, 1/2, h_root, "h(x)"),
        layout = (4, 1), size=(600, 300*3)
        )

savefig(plt, "newton.png")
display(plt)