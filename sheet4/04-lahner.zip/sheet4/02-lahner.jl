using(QuadGK)

quadgk(x->sqrt(1+x^2),0.0,8.0)